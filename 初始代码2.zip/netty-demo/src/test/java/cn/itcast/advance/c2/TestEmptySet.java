package cn.itcast.advance.c2;

import java.util.Collections;

public class TestEmptySet {
    public static void main(String[] args) {
        Collections.EMPTY_SET.add("o");
    }
}
